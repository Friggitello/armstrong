#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int calcolo();

int main(){
	int risultato;
		for (int i = 0;i<=500;i++){
			risultato = calcolo(i);
			if (risultato == i){
				printf("%d\n",risultato);
			}
		}
	return 0;
}

int calcolo(int numero){
	int x;
	if (numero < 10){
		x = numero;
	}
	else if (numero<100){
		x = pow((numero/10),2) + pow((numero%10),2);
	}	
	else {
		x = pow((numero/100),3) + pow(((numero%100)/10),3) + pow((numero%10),3);
	}
	return x;
}
